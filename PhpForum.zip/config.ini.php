<?php
//******************************* Lizenzbestimmungen *******************************//
//                                                                                  //
//  Der Quellcode von diesen Forum ist urheberrechtlich gesch�tzt.                     //
//  Bitte beachten Sie die AGB auf www.frank-karau.de/agb.php                       //
//                                                                                  //
//  Dieser Lizenzhinweis darf nicht entfernt werden.                                //
//                                                                                  //
//  (C) phpFK - Forum ohne MySQL - www.frank-karau.de - support@frank-karau.de      //
//                                                                                  //
//**********************************************************************************//

// Bilder in Beitr�gen automatisch verkleinert darstellen (Angabe in Pixel)
DEFINE('CONFIG_POST_IMG_MAXWIDTH', 600);

// Maximale Zeichenanzahl in Beitr�gen
DEFINE('CONFIG_POST_MAXCHAR', 5000);

?>